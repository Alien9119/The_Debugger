

 Thank you for download my asset!

 Feel free to send me messages or leave a comment if you have questions or need more info.
 


 *Info

   Artwork created by Eder Muniz

   Inspired by Earthbound

   PNG, Gif Formats

   Godot Shaders by @retr0_dev (CC0 license) link:https://godotshaders.com/shader/earthbound-like-battle-background-shader-w-scroll-effect-and-palette-cycling/
   



 *Contents

   PNG Folder            
    -PNG Spritesheets, divided by 4 or 6 horizontally
    

    GIF folder
     -All backgrounds in GIF formats, in 4 or 6 framesV

    BW folder
     -All the backgrounds in black and white versions, for shader use

    Pallette
     -Some palletes that I use for shader




